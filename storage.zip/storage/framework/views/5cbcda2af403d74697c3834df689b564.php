<?php $__env->startSection('Title', 'Dashboard Petugas'); ?>


<?php $__env->startSection('content'); ?>
<main class="p-4 md:ml-64 h-auto pt-20 bg-re">

  <div class="p-4 mb-4 text-white rounded-lg bg-green-500" role="alert">
    <h3 class="text-lg font-bold italic">Welcome, <?php echo e(auth()->user()->name); ?></h3>
  </div>

  

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('petugas.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MSIB\grofa\TOEIC_PNB\resources\views/petugas/content/dashboard.blade.php ENDPATH**/ ?>